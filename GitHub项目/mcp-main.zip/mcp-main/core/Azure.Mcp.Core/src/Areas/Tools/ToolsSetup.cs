// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using Azure.Mcp.Core.Areas.Tools.Commands;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Mcp.Core.Areas;
using Microsoft.Mcp.Core.Commands;

namespace Azure.Mcp.Core.Areas.Tools;

public sealed class ToolsSetup : IAreaSetup
{
    public string Name => "tools";

    public string Title => "MCP Tools Discovery";

    public void ConfigureServices(IServiceCollection services)
    {
        services.AddSingleton<ToolsListCommand>();
    }

    public CommandGroup RegisterCommands(IServiceProvider serviceProvider)
    {
        // Create Tools command group
        var tools = new CommandGroup(Name, "CLI tools operations - Commands for discovering and exploring the functionality available in this CLI tool.", Title);

        var list = serviceProvider.GetRequiredService<ToolsListCommand>();
        tools.AddCommand(list.Name, list);

        return tools;
    }
}
