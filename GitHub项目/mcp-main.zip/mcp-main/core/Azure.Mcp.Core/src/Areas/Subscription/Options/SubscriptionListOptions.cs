// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using Azure.Mcp.Core.Options;

namespace Azure.Mcp.Core.Areas.Subscription.Options;

public class SubscriptionListOptions : GlobalOptions;
