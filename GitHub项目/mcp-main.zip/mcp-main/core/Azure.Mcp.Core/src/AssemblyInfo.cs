// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Azure.Mcp.Core.UnitTests")]
[assembly: InternalsVisibleTo("Azure.Mcp.Core.LiveTests")]
[assembly: InternalsVisibleTo("Azure.Mcp.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
