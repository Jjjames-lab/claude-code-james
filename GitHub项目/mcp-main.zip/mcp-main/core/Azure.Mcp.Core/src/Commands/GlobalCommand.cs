// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Diagnostics.CodeAnalysis;
using System.Net;
using Azure.Core;
using Azure.Identity;
using Azure.Mcp.Core.Models.Option;
using Azure.Mcp.Core.Options;
using Microsoft.Mcp.Core.Commands;

namespace Azure.Mcp.Core.Commands;

public abstract class GlobalCommand<
    [DynamicallyAccessedMembers(TrimAnnotations.CommandAnnotations)] TOptions> : BaseCommand<TOptions>
    where TOptions : GlobalOptions, new()
{
    protected override void RegisterOptions(Command command)
    {
        base.RegisterOptions(command);

        // Add global options
        command.Options.Add(OptionDefinitions.Common.Tenant);
        command.Options.Add(OptionDefinitions.Common.AuthMethod);
        command.Options.Add(OptionDefinitions.RetryPolicy.Delay);
        command.Options.Add(OptionDefinitions.RetryPolicy.MaxDelay);
        command.Options.Add(OptionDefinitions.RetryPolicy.MaxRetries);
        command.Options.Add(OptionDefinitions.RetryPolicy.Mode);
        command.Options.Add(OptionDefinitions.RetryPolicy.NetworkTimeout);
    }

    // Helper to get the command path for examples
    protected virtual string GetCommandPath()
    {
        // Get the command type name without the "Command" suffix
        string commandName = GetType().Name.Replace("Command", "");

        // Get the namespace to determine the service name
        string namespaceName = GetType().Namespace ?? "";
        string serviceName = "";

        // Extract service name from namespace (e.g., Azure.Mcp.Tools.Cosmos.Commands -> cosmos)
        if (!string.IsNullOrEmpty(namespaceName) && namespaceName.Contains(".Commands."))
        {
            string[] parts = namespaceName.Split(".Commands.");
            if (parts.Length > 1)
            {
                string[] subParts = parts[1].Split('.');
                if (subParts.Length > 0)
                {
                    serviceName = subParts[0].ToLowerInvariant();
                }
            }
        }

        // Insert spaces before capital letters in the command name
        string formattedName = string.Concat(commandName.Select(x => char.IsUpper(x) ? " " + x : x.ToString())).Trim();

        // Convert to lowercase and replace spaces with spaces (for readability in command examples)
        string commandPath = formattedName.ToLowerInvariant().Replace(" ", " ");

        // Prepend the service name if available
        if (!string.IsNullOrEmpty(serviceName))
        {
            commandPath = serviceName + " " + commandPath;
        }

        return commandPath;
    }
    protected override TOptions BindOptions(ParseResult parseResult)
    {
        var options = new TOptions
        {
            Tenant = parseResult.GetValueOrDefault<string>(OptionDefinitions.Common.Tenant.Name),
            AuthMethod = parseResult.GetValueOrDefault<AuthMethod>(OptionDefinitions.Common.AuthMethod.Name)
        };

        // Create a RetryPolicyOptions capturing only explicitly provided values so unspecified settings remain SDK defaults
        var hasAnyRetry = Options.ParseResultExtensions.HasAnyRetryOptions(parseResult);
        if (hasAnyRetry)
        {
            var policy = new RetryPolicyOptions();

            policy.HasMaxRetries = parseResult.TryGetValue(OptionDefinitions.RetryPolicy.MaxRetries.Name, out int maxRetries);
            policy.MaxRetries = maxRetries;

            policy.HasDelaySeconds = parseResult.TryGetValue(OptionDefinitions.RetryPolicy.Delay.Name, out double delaySeconds);
            policy.DelaySeconds = delaySeconds;

            policy.HasMaxDelaySeconds = parseResult.TryGetValue(OptionDefinitions.RetryPolicy.MaxDelay.Name, out double maxDelaySeconds);
            policy.MaxDelaySeconds = maxDelaySeconds;

            policy.HasMode = parseResult.TryGetValue(OptionDefinitions.RetryPolicy.Mode.Name, out RetryMode mode);
            policy.Mode = mode;

            policy.HasNetworkTimeoutSeconds = parseResult.TryGetValue(OptionDefinitions.RetryPolicy.NetworkTimeout.Name, out double networkTimeoutSeconds);
            policy.NetworkTimeoutSeconds = networkTimeoutSeconds;

            // Only assign if at least one flag set (defensive)
            if (policy.HasMaxRetries || policy.HasDelaySeconds || policy.HasMaxDelaySeconds || policy.HasMode || policy.HasNetworkTimeoutSeconds)
            {
                options.RetryPolicy = policy;
            }
        }

        return options;
    }

    protected override string GetErrorMessage(Exception ex) => ex switch
    {
        AuthenticationFailedException authEx =>
            $"Authentication failed. Please run 'az login' to sign in to Azure. Details: {authEx.Message}",
        RequestFailedException rfEx => rfEx.Message,
        HttpRequestException httpEx =>
            $"Service unavailable or network connectivity issues. Details: {httpEx.Message}",
        _ => ex.Message  // Just return the actual exception message
    };

    protected override HttpStatusCode GetStatusCode(Exception ex) => ex switch
    {
        KeyNotFoundException => HttpStatusCode.NotFound,
        AuthenticationFailedException => HttpStatusCode.Unauthorized,
        RequestFailedException rfEx => (HttpStatusCode)rfEx.Status,
        HttpRequestException => HttpStatusCode.ServiceUnavailable,
        _ => HttpStatusCode.InternalServerError
    };
}
