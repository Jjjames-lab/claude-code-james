// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.CommandLine.Help;
using System.Diagnostics;
using System.Net;
using System.Reflection;
using System.Text.Encodings.Web;
using System.Text.Json.Serialization;
using Azure.Mcp.Core.Configuration;
using Azure.Mcp.Core.Services.Telemetry;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Mcp.Core.Areas;
using Microsoft.Mcp.Core.Commands;
using Microsoft.Mcp.Core.Models.Command;

namespace Azure.Mcp.Core.Commands;

public class CommandFactory
{
    private readonly IAreaSetup[] _serviceAreas;
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<CommandFactory> _logger;
    private readonly RootCommand _rootCommand;
    private readonly CommandGroup _rootGroup;
    private readonly ModelsJsonContext _srcGenWithOptions;

    public const char Separator = '_';

    /// <summary>
    /// Mapping of tokenized command names to their <see cref="IBaseCommand" />
    /// </summary>
    private readonly Dictionary<string, IBaseCommand> _commandMap;
    private readonly Dictionary<string, IAreaSetup> _commandNamesToArea = new(StringComparer.OrdinalIgnoreCase);
    private readonly ITelemetryService _telemetryService;
    private readonly IOptions<AzureMcpServerConfiguration> _configurationOptions;

    // Add this new class inside CommandFactory
    private class StringConverter : JsonConverter<string>
    {
        public override string Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return reader.GetString() ?? string.Empty;
        }

        public override void Write(Utf8JsonWriter writer, string value, JsonSerializerOptions options)
        {
            var cleanValue = value?.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
            writer.WriteStringValue(cleanValue);
        }
    }


    public CommandFactory(IServiceProvider serviceProvider,
        IEnumerable<IAreaSetup> serviceAreas,
        ITelemetryService telemetryService,
        IOptions<AzureMcpServerConfiguration> configurationOptions,
        ILogger<CommandFactory> logger)
    {
        _serviceAreas = serviceAreas?.ToArray() ?? throw new ArgumentNullException(nameof(serviceAreas));
        _serviceProvider = serviceProvider;
        _logger = logger;
        _telemetryService = telemetryService;
        _configurationOptions = configurationOptions;
        _rootGroup = new CommandGroup(_configurationOptions.Value.RootCommandGroupName, _configurationOptions.Value.DisplayName);
        _rootCommand = CreateRootCommand();
        _commandMap = CreateCommandDictionary(_rootGroup);
        _srcGenWithOptions = new ModelsJsonContext(new JsonSerializerOptions
        {
            WriteIndented = true,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        });
    }

    public RootCommand RootCommand => _rootCommand;

    public CommandGroup RootGroup => _rootGroup;

    public IReadOnlyDictionary<string, IBaseCommand> AllCommands => _commandMap;

    public IReadOnlyDictionary<string, IBaseCommand> GroupCommands(string[] groupNames)
    {
        if (groupNames is null)
        {
            throw new ArgumentException("groupNames cannot be null.");
        }
        Dictionary<string, IBaseCommand> commandsFromGroups = new();
        foreach (string groupName in groupNames)
        {
            foreach (CommandGroup group in _rootGroup.SubGroup)
            {
                if (string.Equals(group.Name, groupName, StringComparison.OrdinalIgnoreCase))
                {
                    var commandsInGroup = CreateCommandDictionaryInner(group, string.Empty);
                    foreach (var (key, value) in commandsInGroup)
                    {
                        commandsFromGroups[key] = value;
                    }
                    break;
                }
            }
        }

        return commandsFromGroups;
    }

    private void RegisterCommandGroup()
    {
        // Register area command groups
        var existingAreaNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var area in _serviceAreas)
        {
            if (string.IsNullOrEmpty(area.Name))
            {
                var error = new ArgumentException("IAreaSetup cannot have an empty or null name. Type "
                    + area.GetType());
                _logger.LogError(error, "Invalid IAreaSetup encountered. Type: {Type}", area.GetType());

                throw error;
            }

            if (!existingAreaNames.Add(area.Name))
            {
                var matchingAreaTypes = _serviceAreas
                    .Where(x => string.Equals(x.Name, area.Name, StringComparison.OrdinalIgnoreCase))
                    .Select(a => a.GetType().FullName);

                var error = new ArgumentException("Cannot have multiple IAreaSetup with the same Name.");
                _logger.LogError(error,
                    "Duplicate {AreaName}. Areas with same name: {AllAreaTypes}",
                    area.Name,
                    string.Join(", ", matchingAreaTypes));

                throw error;
            }

            // Get the commands for the IAreaSetup and register it to the root node.
            var commandTree = area.RegisterCommands(_serviceProvider);
            _rootGroup.AddSubGroup(commandTree);

            // Create a temporary root node to register all the area's subgroups and commands to.
            // Use this to create the mapping of all commands to that area.
            var tempRoot = new CommandGroup(_rootGroup.Name, string.Empty);
            tempRoot.AddSubGroup(commandTree);

            var commandDictionary = CreateCommandDictionary(tempRoot);

            if (_logger.IsEnabled(LogLevel.Debug))
            {
                _logger.LogDebug("Registered commands for area '{AreaName}' are: {AllCommands}.",
                    area.Name, string.Join(", ", commandDictionary.Keys));
            }

            foreach (var item in commandDictionary)
            {
                _commandNamesToArea.Add(item.Key, area);
            }
        }
    }

    private void ConfigureCommands(CommandGroup group)
    {
        // Configure direct commands in this group
        foreach (var command in group.Commands.Values)
        {
            var cmd = command.GetCommand();

            ConfigureCommandHandler(cmd, command);

            group.Command.Subcommands.Add(cmd);
        }

        // Recursively configure subgroup commands
        foreach (var subGroup in group.SubGroup)
        {
            ConfigureCommands(subGroup);
        }
    }

    private void ConfigureCommandHandler(Command command, IBaseCommand implementation)
    {
        command.SetAction(async (parseResult, ct) =>
        {
            _logger.LogTrace("Executing '{Command}'.", command.Name);

            using var activity = _telemetryService.StartActivity(ActivityName.CommandExecuted);
            activity?.SetTag(TagName.ToolId, implementation.Id);
            var cmdContext = new CommandContext(_serviceProvider, activity);
            var startTime = DateTime.UtcNow;
            try
            {
                // Centralized preflight validation before executing the command
                var validation = implementation.Validate(parseResult.CommandResult, cmdContext.Response);
                if (!validation.IsValid)
                {
                    Console.WriteLine(JsonSerializer.Serialize(cmdContext.Response, _srcGenWithOptions.CommandResponse));
                    return (int)cmdContext.Response.Status;
                }

                var response = await implementation.ExecuteAsync(cmdContext, parseResult, ct);

                // Calculate execution time
                var endTime = DateTime.UtcNow;
                response.Duration = (long)(endTime - startTime).TotalMilliseconds;

                if (response.Status == HttpStatusCode.OK && response.Results == null)
                {
                    response.Results = ResponseResult.Create(new List<string>(), JsonSourceGenerationContext.Default.ListString);
                }

                var isServiceStartCommand = implementation is Areas.Server.Commands.ServiceStartCommand;
                if (!isServiceStartCommand)
                {
                    Console.WriteLine(JsonSerializer.Serialize(response, _srcGenWithOptions.CommandResponse));
                }

                if (response.Status < HttpStatusCode.OK || response.Status >= HttpStatusCode.Ambiguous)
                {
                    activity?.SetStatus(ActivityStatusCode.Error).AddTag(TagName.ErrorDetails, response.Message);
                }

                return (int)response.Status;
            }
            catch (Exception ex)
            {
                _logger.LogError("An exception occurred while executing '{Command}'. Exception: {Exception}",
                    command.Name, ex);
                activity?.SetStatus(ActivityStatusCode.Error)?.AddTag(TagName.ErrorDetails, ex.Message);
                return 1;
            }
            finally
            {
                _logger.LogTrace("Finished running '{Command}'.", command.Name);
            }
        });
    }

    private RootCommand CreateRootCommand()
    {
        // RootCommand title/description comes from the root group
        var root = new RootCommand(_rootGroup.Description);

        CustomizeHelpOption(root);

        // Register area groups and their commands
        RegisterCommandGroup();

        // Attach subgroups to the root and configure their commands/actions
        foreach (var subGroup in _rootGroup.SubGroup)
        {
            ConfigureCommands(subGroup);
            root.Subcommands.Add(subGroup.Command);
            subGroup.Command.Options.Add(new HelpOption());

            CustomizeHelpOption(subGroup.Command);
        }

        return root;
    }

    private void CustomizeHelpOption(Command command)
    {
        for (int i = 0; i < command.Options.Count; i++)
        {
            if (command.Options[i] is HelpOption helpOption && helpOption.Action is HelpAction helpAction)
            {
                helpOption.Action = new VersionDisplayHelpAction(_configurationOptions, helpAction);
                break;
            }
        }
    }

    private static IBaseCommand? FindCommandInGroup(CommandGroup group, Queue<string> nameParts)
    {
        // If we've processed all parts and this group has a matching command, return it
        if (nameParts.Count == 1)
        {
            var commandName = nameParts.Dequeue();
            return group.Commands.GetValueOrDefault(commandName);
        }

        // Find the next subgroup
        var groupName = nameParts.Dequeue();
        var nextGroup = group.SubGroup.FirstOrDefault(g => g.Name == groupName);

        return nextGroup != null ? FindCommandInGroup(nextGroup, nameParts) : null;
    }

    /// <summary>
    /// Finds the BaseCommand given its full command name (i.e. storage_account_list).
    /// </summary>
    /// <param name="fullCommandName">Name of the command with prefixes.</param>
    /// <returns></returns>
    public IBaseCommand? FindCommandByName(string fullCommandName)
    {
        return _commandMap.GetValueOrDefault(fullCommandName);
    }

    /// <summary>
    /// Gets the service area given the full command name (i.e. 'storage_account_list' would return 'storage').
    /// </summary>
    /// <param name="fullCommandName">Name of the command.</param>
    public string? GetServiceArea(string fullCommandName)
    {
        if (string.IsNullOrEmpty(fullCommandName))
        {
            return null;
        }

        if (_commandNamesToArea.TryGetValue(fullCommandName, out var area))
        {
            return area.Name;
        }
        else
        {
            return null;
        }
    }

    /// <summary>
    /// Creates a command dictionary. Each sibling and child of the root node is created without using its name as a prefix.
    ///
    /// Node: RootNode
    /// * Siblings: A11, A12
    /// * Children (Subgroups): B1, B2
    ///
    /// Node: B1
    /// * Siblings: B11
    /// * Children: C1, C2
    ///
    /// The command dictionary would be output:
    /// - A11
    /// - A12
    /// - B1_B11
    /// - B1_C1
    /// - B1_C2
    /// - B2
    /// </summary>
    /// <param name="rootNode">Node to begin traversal.</param>
    internal static Dictionary<string, IBaseCommand> CreateCommandDictionary(CommandGroup rootNode)
    {
        const string rootPrefix = "";
        var aggregated = new Dictionary<string, IBaseCommand>();

        // Add any immediate commands from root group.
        foreach (var kvp in rootNode.Commands)
        {
            aggregated.Add(kvp.Key, kvp.Value);
        }

        // Add any sub commands.
        foreach (var command in rootNode.SubGroup)
        {
            var temp = CreateCommandDictionaryInner(command, rootPrefix);

            foreach (var kvp in temp)
            {
                aggregated.Add(kvp.Key, kvp.Value);
            }
        }

        return aggregated;
    }

    /// <summary>
    /// Creates a command dictionary. Each direct node and descendent is created with its parent's name as
    /// its first prefix.  For example, given the tree:
    ///
    /// Node: A1
    /// * Siblings: A11, A12
    /// * Children (Subgroups): B1, B2
    ///
    /// Node: B1
    /// * Siblings: B11
    /// * Children: C1, C2
    ///
    /// The command dictionary would be output:
    /// - A1_A11
    /// - A1_A12
    /// - A1_B1_B11
    /// - A1_B1_C1
    /// - A1_B1_C2
    /// - A1_B2
    /// </summary>
    /// <param name="node">Node to begin traversal.</param>
    /// <param name="prefix">Prefix. If prefix is an empty string, the name of the current node is used.</param>
    internal static Dictionary<string, IBaseCommand> CreateCommandDictionaryInner(CommandGroup node, string prefix)
    {
        var aggregated = new Dictionary<string, IBaseCommand>();
        var updatedPrefix = GetPrefix(prefix, node.Name);

        if (node.Commands != null)
        {
            foreach (var kvp in node.Commands)
            {
                var key = GetPrefix(updatedPrefix, kvp.Key);
                aggregated.Add(key, kvp.Value);
            }
        }

        if (node.SubGroup == null)
        {
            return aggregated;
        }

        foreach (var command in node.SubGroup)
        {
            var subcommandsDictionary = CreateCommandDictionaryInner(command, updatedPrefix);
            foreach (var item in subcommandsDictionary)
            {
                aggregated.Add(item.Key, item.Value);
            }
        }

        return aggregated;
    }

    internal static string GetPrefix(string currentPrefix, string additional) => string.IsNullOrEmpty(currentPrefix)
        ? additional
        : currentPrefix + Separator + additional;

    public static IEnumerable<KeyValuePair<string, IBaseCommand>> GetVisibleCommands(IEnumerable<KeyValuePair<string, IBaseCommand>> commands)
    {
        return commands
            .Where(kvp => kvp.Value.GetType().GetCustomAttribute<HiddenCommandAttribute>() == null)
            .OrderBy(kvp => kvp.Key);
    }
}
