// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using Azure.Core;
using Azure.Core.Pipeline;
using Azure.Mcp.Core.Services.Azure.Authentication;
using Azure.Mcp.Core.Services.Caching;
using Azure.ResourceManager;
using Azure.ResourceManager.Resources;

namespace Azure.Mcp.Core.Services.Azure.Tenant;

public class TenantService : BaseAzureService, ITenantService
{
    private readonly IAzureTokenCredentialProvider _credentialProvider;
    private readonly ICacheService _cacheService;
    private readonly IHttpClientFactory _httpClientFactory;
    private const string CacheGroup = "tenant";
    private const string CacheKey = "tenants";
    private static readonly TimeSpan s_cacheDuration = TimeSpan.FromHours(12);

    public TenantService(
        IAzureTokenCredentialProvider credentialProvider,
        ICacheService cacheService,
        IHttpClientFactory clientFactory)
    {
        _credentialProvider = credentialProvider;
        _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        _httpClientFactory = clientFactory ?? throw new ArgumentNullException(nameof(clientFactory));
        TenantService = this;
    }

    /// <inheritdoc/>
    public async Task<List<TenantResource>> GetTenants(CancellationToken cancellationToken)
    {
        // Try to get from cache first
        var cachedResults = await _cacheService.GetAsync<List<TenantResource>>(CacheGroup, CacheKey, s_cacheDuration, cancellationToken);
        if (cachedResults != null)
        {
            return cachedResults;
        }

        // If not in cache, fetch from Azure
        var results = new List<TenantResource>();

        var options = AddDefaultPolicies(new ArmClientOptions());
        options.Transport = new HttpClientTransport(GetClient());
        var client = new ArmClient(await GetCredential(cancellationToken), default, options);

        await foreach (var tenant in client.GetTenants())
        {
            results.Add(tenant);
        }

        // Cache the results
        await _cacheService.SetAsync(CacheGroup, CacheKey, results, s_cacheDuration, cancellationToken);
        return results;
    }

    /// <inheritdoc/>
    public bool IsTenantId(string tenantId)
    {
        return Guid.TryParse(tenantId, out _);
    }

    /// <inheritdoc/>
    public async Task<string> GetTenantId(string tenantIdOrName, CancellationToken cancellationToken)
    {
        if (IsTenantId(tenantIdOrName))
        {
            return tenantIdOrName;
        }

        return await GetTenantIdByName(tenantIdOrName, cancellationToken);
    }

    /// <inheritdoc/>
    public async Task<string> GetTenantIdByName(string tenantName, CancellationToken cancellationToken)
    {
        var tenants = await GetTenants(cancellationToken);
        var tenant = tenants.FirstOrDefault(t => t.Data.DisplayName?.Equals(tenantName, StringComparison.OrdinalIgnoreCase) == true) ??
            throw new Exception($"Could not find tenant with name {tenantName}");

        string? tenantId = tenant.Data.TenantId?.ToString();
        if (tenantId == null)
            throw new InvalidOperationException($"Tenant {tenantName} has a null TenantId");

        return tenantId.ToString();
    }

    /// <inheritdoc/>
    public async Task<string> GetTenantNameById(string tenantId, CancellationToken cancellationToken)
    {
        var tenants = await GetTenants(cancellationToken);
        var tenant = tenants.FirstOrDefault(t => t.Data.TenantId?.ToString().Equals(tenantId, StringComparison.OrdinalIgnoreCase) == true) ??
            throw new Exception($"Could not find tenant with ID {tenantId}");

        string? tenantName = tenant.Data.DisplayName;
        if (tenantName == null)
            throw new InvalidOperationException($"Tenant with ID {tenantId} has a null DisplayName");

        return tenantName;
    }

    /// <inheritdoc/>
    public async Task<TokenCredential> GetTokenCredentialAsync(string? tenantId, CancellationToken cancellationToken)
    {
        return await _credentialProvider.GetTokenCredentialAsync(tenantId, cancellationToken);
    }

    /// <inheritdoc/>
    public HttpClient GetClient()
    {
        return _httpClientFactory.CreateClient();
    }
}
