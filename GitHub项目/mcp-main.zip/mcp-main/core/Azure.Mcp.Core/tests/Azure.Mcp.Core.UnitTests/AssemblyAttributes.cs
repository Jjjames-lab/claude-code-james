﻿[assembly: Azure.Mcp.Tests.Helpers.ClearEnvironmentVariablesBeforeTest]
[assembly: Xunit.CollectionBehavior(Xunit.CollectionBehavior.CollectionPerAssembly)]
