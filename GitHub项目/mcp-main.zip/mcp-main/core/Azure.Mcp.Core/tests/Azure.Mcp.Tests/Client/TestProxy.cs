// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Diagnostics;
using System.Formats.Tar;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Azure.Mcp.Tests.Generated;

namespace Azure.Mcp.Tests.Client;

/// <summary>
/// Lightweight test-proxy process manager used per test class to start/stop the Azure SDK test proxy.
/// This version intentionally avoids dependencies on prior internal abstractions that were missing
/// (e.g. TestEnvironment / ProcessTracker) while still providing stderr/stdout capture for failed tests.
/// </summary>
public sealed class TestProxy(bool debug = false) : IDisposable
{
    private readonly bool _debug = debug;
    public StringBuilder stderr = new();
    public readonly StringBuilder stdout = new();
    private Process? _process;
    private CancellationTokenSource? _cts;
    private int? _httpPort;
    private bool _disposed;

    public string BaseUri => _httpPort is int p ? $"http://127.0.0.1:{p}/" : throw new InvalidOperationException("Proxy not started");

    public TestProxyClient Client { get; private set; } = default!;
    public TestProxyAdminClient AdminClient { get; private set; } = default!;

    private static string? _cachedRootDir;
    private static string? _cachedExecutable;
    private static string? _cachedVersion;
    private static readonly TimeSpan[] DownloadRetryDelays = new[]
    {
        TimeSpan.FromSeconds(1),
        TimeSpan.FromSeconds(10),
        TimeSpan.FromSeconds(60)
    };

    /// <summary>
    /// In-process synchronization lock to avoid proxy exe mismanagement.
    /// </summary>
    private static readonly SemaphoreSlim s_downloadLock = new(1, 1);

    private async Task<string> EnsureProxyExecutableAsync(string repositoryRoot, string assetsJsonPath)
    {
        if (_cachedExecutable != null)
        {
            return _cachedExecutable;
        }

        await s_downloadLock.WaitAsync().ConfigureAwait(false);
        try
        {
            var proxyDir = GetProxyDirectory();
            using var lockStream = await AcquireDownloadLockAsync(proxyDir).ConfigureAwait(false);

            if (_cachedExecutable != null)
            {
                return _cachedExecutable;
            }

            var version = GetTargetVersion();

            if (CheckProxyVersion(proxyDir, version))
            {
                _cachedExecutable = FindExecutableInDirectory(proxyDir);
                return _cachedExecutable;
            }

            await DownloadProxyAsync(proxyDir, version);

            _cachedExecutable = FindExecutableInDirectory(proxyDir);

            if (string.IsNullOrWhiteSpace(_cachedExecutable))
            {
                throw new InvalidOperationException("Unable to locate freshly downloaded test-proxy executable.");
            }
        }
        finally
        {
            s_downloadLock.Release();
        }

        return _cachedExecutable;
    }

    private async Task EnsureProxyRecordings(string proxyExe, string repositoryRoot, string assetsJsonPath)
    {
        await s_downloadLock.WaitAsync().ConfigureAwait(false);
        FileStream? lockStream = null;
        try
        {
            var proxyDir = GetProxyDirectory();
            lockStream = await AcquireDownloadLockAsync(proxyDir).ConfigureAwait(false);

            await RestoreAssetsAsync(proxyExe, assetsJsonPath, repositoryRoot).ConfigureAwait(false);
        }
        finally
        {
            lockStream?.Dispose();
            s_downloadLock.Release();
        }
    }

    private async Task DownloadProxyAsync(string proxyDirectory, string version)
    {
        var assetName = GetAssetNameForPlatform();
        var url = $"https://github.com/Azure/azure-sdk-tools/releases/download/Azure.Sdk.Tools.TestProxy_{version}/{assetName}";
        var downloadPath = Path.Combine(proxyDirectory, assetName);

        if (File.Exists(downloadPath))
        {
            File.Delete(downloadPath);
        }

        using var client = new HttpClient();
        byte[] bytes = await DownloadWithRetryAsync(client, url).ConfigureAwait(false);
        await File.WriteAllBytesAsync(downloadPath, bytes).ConfigureAwait(false);

        var toolDirectory = Path.Combine(proxyDirectory, "Azure.Sdk.Tools.TestProxy");
        if (Directory.Exists(toolDirectory))
        {
            Directory.Delete(toolDirectory, recursive: true);
        }

        if (assetName.EndsWith(".tar.gz", StringComparison.OrdinalIgnoreCase))
        {
            await using var compressedStream = File.OpenRead(downloadPath);
            using var gzipStream = new GZipStream(compressedStream, CompressionMode.Decompress, leaveOpen: false);
            TarFile.ExtractToDirectory(gzipStream, proxyDirectory, overwriteFiles: true);
        }
        else
        {
            ZipFile.ExtractToDirectory(downloadPath, proxyDirectory, overwriteFiles: true);
        }

        await File.WriteAllTextAsync(Path.Combine(proxyDirectory, "version.txt"), version).ConfigureAwait(false);
    }

    private static async Task<byte[]> DownloadWithRetryAsync(HttpClient client, string url)
    {
        var attempt = 0;
        while (true)
        {
            try
            {
                return await client.GetByteArrayAsync(url).ConfigureAwait(false);
            }
            catch when (attempt < DownloadRetryDelays.Length)
            {
                var delay = DownloadRetryDelays[attempt];
                await Task.Delay(delay).ConfigureAwait(false);
                attempt++;
            }
        }
    }

    private static async Task RestoreAssetsAsync(string proxyExe, string assetsJsonPath, string repositoryRoot)
    {
        var resolvedAssetsPath = Path.IsPathRooted(assetsJsonPath)
            ? assetsJsonPath
            : Path.GetFullPath(assetsJsonPath, repositoryRoot);

        if (!File.Exists(resolvedAssetsPath))
        {
            throw new FileNotFoundException($"Assets file not found: {resolvedAssetsPath}");
        }

        var psi = new ProcessStartInfo(proxyExe, $"restore -a \"{resolvedAssetsPath}\" --storage-location=\"{repositoryRoot}\"")
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            WorkingDirectory = repositoryRoot,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi) ?? throw new InvalidOperationException("Failed to start test proxy restore process.");
        var stdoutTask = process.StandardOutput.ReadToEndAsync();
        var stderrTask = process.StandardError.ReadToEndAsync();

        await process.WaitForExitAsync().ConfigureAwait(false);
        var stdout = await stdoutTask.ConfigureAwait(false);
        var stderr = await stderrTask.ConfigureAwait(false);

        if (process.ExitCode != 0)
        {
            throw new InvalidOperationException($"Test proxy restore failed with exit code {process.ExitCode}. StdOut: {stdout}. StdErr: {stderr}");
        }
    }

    /// <summary>
    /// Multiple test assemblies are likely to be running in the same process due to MCP repo's usage of dotnet test
    ///
    /// This can lead to race conditions on making the proxy exe available on disk. To avoid this, we use a semaphore slim
    /// to maintain in-process synchronization, and a file lock to maintain cross-process synchronization.
    /// </summary>
    /// <param name="proxyDirectory"></param>
    /// <returns></returns>
    private static async Task<FileStream> AcquireDownloadLockAsync(string proxyDirectory)
    {
        var lockPath = Path.Combine(proxyDirectory, ".download.lock");

        while (true)
        {
            try
            {
                return new FileStream(lockPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None, bufferSize: 1, FileOptions.DeleteOnClose);
            }
            catch (IOException)
            {
                await Task.Delay(200).ConfigureAwait(false);
            }
        }
    }

    private bool CheckProxyVersion(string proxyDirectory, string version)
    {
        var versionFilePath = Path.Combine(proxyDirectory, "version.txt");
        if (File.Exists(versionFilePath))
        {
            var existingVersion = File.ReadAllText(versionFilePath).Trim();
            if (existingVersion == version)
            {
                return true;
            }
        }
        return false;
    }

    private string GetAssetNameForPlatform()
    {
        var arch = RuntimeInformation.ProcessArchitecture;
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            return (arch == Architecture.Arm64 ? "test-proxy-standalone-win-arm64.zip" : "test-proxy-standalone-win-x64.zip");
        }
        if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
        {
            return (arch == Architecture.Arm64 ? "test-proxy-standalone-osx-arm64.zip" : "test-proxy-standalone-osx-x64.zip");
        }
        return (arch == Architecture.Arm64 ? "test-proxy-standalone-linux-arm64.tar.gz" : "test-proxy-standalone-linux-x64.tar.gz");
    }

    private string FindExecutableInDirectory(string dir)
    {
        var exeName = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? "Azure.Sdk.Tools.TestProxy.exe" : "Azure.Sdk.Tools.TestProxy";
        foreach (var file in Directory.EnumerateFiles(dir, exeName, SearchOption.AllDirectories))
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                EnsureExecutable(file);
            }
            return file;
        }
        throw new FileNotFoundException($"Could not find {exeName} in {dir}");
    }

    private void EnsureExecutable(string path)
    {
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            return;
        }

        var mode = File.GetUnixFileMode(path);
        if (!mode.HasFlag(UnixFileMode.UserExecute))
        {
            File.SetUnixFileMode(path, mode | UnixFileMode.UserExecute | UnixFileMode.GroupExecute | UnixFileMode.OtherExecute);
        }
    }

    private string GetRootDirectory()
    {
        if (_cachedRootDir != null)
        {
            return _cachedRootDir;
        }
        var current = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? Directory.GetCurrentDirectory();
        while (current != null)
        {
            var gitPath = Path.Combine(current, ".git");
            if (File.Exists(gitPath) || Directory.Exists(gitPath))
            {
                _cachedRootDir = current;
                return _cachedRootDir;
            }
            current = Directory.GetParent(current)?.FullName;
        }

        throw new InvalidOperationException("Could not find repository root (.git)");
    }

    private string GetTargetVersion()
    {
        if (_cachedVersion != null)
        {
            return _cachedVersion;
        }

        var versionFile = Path.Combine(GetRootDirectory(), "eng", "common", "testproxy", "target_version.txt");
        if (!File.Exists(versionFile))
        {
            throw new FileNotFoundException($"Test proxy version file not found: {versionFile}");
        }
        _cachedVersion = File.ReadAllText(versionFile).Trim();
        return _cachedVersion;
    }

    private string GetProxyDirectory()
    {
        var root = GetRootDirectory();
        var proxyDirectory = Path.Combine(root, ".proxy");
        if (!Directory.Exists(proxyDirectory))
        {
            Directory.CreateDirectory(proxyDirectory);
        }
        return proxyDirectory;
    }

    public async Task Start(string repositoryRoot, string assetsJsonPath)
    {
        if (_process != null)
        {
            return;
        }

        var proxyExe = await EnsureProxyExecutableAsync(repositoryRoot, assetsJsonPath).ConfigureAwait(false);
        await EnsureProxyRecordings(proxyExe, repositoryRoot, assetsJsonPath).ConfigureAwait(false);

        if (string.IsNullOrWhiteSpace(proxyExe) || !File.Exists(proxyExe))
        {
            throw new InvalidOperationException("Unable to locate test-proxy executable.");
        }

        var storageLocation = Environment.GetEnvironmentVariable("TEST_PROXY_STORAGE") ?? repositoryRoot;
        var args = $"start --http-proxy --storage-location=\"{storageLocation}\"";

        ProcessStartInfo psi = new(proxyExe, args);
        psi.RedirectStandardOutput = true;
        psi.RedirectStandardError = true;
        psi.UseShellExecute = false;
        psi.EnvironmentVariables["ASPNETCORE_URLS"] = "http://127.0.0.1:0"; // Let proxy choose free port

        _process = Process.Start(psi);

        if (_process == null)
        {
            throw new InvalidOperationException("Failed to start test proxy process.");
        }
        _cts = new CancellationTokenSource();
        _ = Task.Run(() => _pumpAsync(_process.StandardError, stderr, _cts.Token));
        _ = Task.Run(() => _pumpAsync(_process.StandardOutput, stdout, _cts.Token));

        if (!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("PROXY_MANUAL_START")))
        {
            _httpPort = 5000;
        }
        else
        {
            _httpPort = _waitForHttpPort(TimeSpan.FromSeconds(15));
        }

        if (_httpPort is null)
        {
            throw new InvalidOperationException($"Failed to detect test-proxy HTTP port. Output: {stdout}\nErrors: {stderr}");
        }

        Client = new TestProxyClient(new Uri(BaseUri), new TestProxyClientOptions());
        AdminClient = Client.GetTestProxyAdminClient();
    }

    private static async Task _pumpAsync(StreamReader reader, StringBuilder sink, CancellationToken ct)
    {
        try
        {
            while (!ct.IsCancellationRequested && !reader.EndOfStream)
            {
                var line = await reader.ReadLineAsync(ct).ConfigureAwait(false);
                if (line == null)
                    break;
                lock (sink)
                {
                    sink.AppendLine(line);
                }
            }
        }
        catch { /* swallow */ }
    }

    private int? _waitForHttpPort(TimeSpan timeout)
    {
        var start = DateTime.UtcNow;
        while ((DateTime.UtcNow - start) < timeout)
        {
            string text;
            lock (stdout)
            {
                text = stdout.ToString();
            }
            foreach (var line in text.Split('\n'))
            {
                if (_tryParsePort(line.Trim(), out var p))
                {
                    return p;
                }
            }
            if (_process?.HasExited == true)
                break;
            Thread.Sleep(50);
        }
        return null;
    }

    private static bool _tryParsePort(string line, out int port)
    {
        port = 0;
        const string prefix = "Now listening on: http://127.0.0.1:";
        if (!line.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            return false;
        var remainder = line[prefix.Length..].TrimEnd('/', '\r');
        return int.TryParse(remainder, out port);
    }

    /// <summary>
    /// Snapshots the current stderr output from the testproxy. This is a destructive read; the internal buffer is cleared after the call.
    ///
    /// This means that if multiple tests fail in sequence, each test will only see the stderr output generated since the last call to SnapshotStdErr(), which means
    /// we won't be seeing errors from previous test failures. This is intentional to ensure that each test only gets the relevant stderr output.
    /// </summary>
    /// <returns></returns>
    public string? SnapshotStdErr()
    {
        lock (stderr)
        {
            var toOutput = stderr.Length == 0 ? null : stderr.ToString();

            stderr = new();

            return toOutput;
        }
    }

    public void Dispose()
    {
        if (_disposed)
            return;
        _disposed = true;

        _cts?.Cancel();
        _cts?.Dispose();

        if (_process != null && !_process.HasExited)
        {
            _process.Kill();
        }
        _process?.Dispose();
    }
}
