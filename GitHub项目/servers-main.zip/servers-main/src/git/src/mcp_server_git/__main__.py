# __main__.py

from mcp_server_git import main

main()
