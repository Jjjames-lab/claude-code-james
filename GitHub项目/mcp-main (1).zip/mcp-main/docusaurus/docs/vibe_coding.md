---
title: Vibe Coding Tips and Tricks
---

import ReadmeContent from "../../VIBE_CODING_TIPS_TRICKS.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
