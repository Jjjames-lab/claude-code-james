---
title: MCP Integration with Amazon Bedrock Knowledge Bases
---

import ReadmeContent from "../../../samples/mcp-integration-with-kb/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
