---
title: MCP Integration with Amazon Nova Canvas
---


import ReadmeContent from "../../../samples/mcp-integration-with-nova-canvas/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
