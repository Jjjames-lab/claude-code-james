---
title: AWS MCP Servers - Samples
---

import ReadmeContent from "../../../samples/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
