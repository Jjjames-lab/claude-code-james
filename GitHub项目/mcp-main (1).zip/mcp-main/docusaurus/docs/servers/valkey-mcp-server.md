---
title: Amazon ElastiCache/MemoryDB for Valkey MCP Server
---

import ReadmeContent from "../../../src/valkey-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
