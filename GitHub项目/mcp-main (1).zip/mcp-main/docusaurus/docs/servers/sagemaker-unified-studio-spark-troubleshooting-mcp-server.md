---
title: Amazon SageMaker Unified Studio MCP for Spark Troubleshooting and Code Recommendation
---

import ReadmeContent from "../../../src/sagemaker-unified-studio-spark-troubleshooting-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
