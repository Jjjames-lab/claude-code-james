---
title: AWS S3 Tables MCP Server
---

import ReadmeContent from "../../../src/s3-tables-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
