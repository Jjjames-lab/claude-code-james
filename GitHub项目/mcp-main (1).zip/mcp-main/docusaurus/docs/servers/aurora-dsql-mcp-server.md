---
title: Amazon Aurora DSQL MCP Server
---

import ReadmeContent from "../../../src/aurora-dsql-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
