---
title: AWS Cloud Control API MCP Server
---

import ReadmeContent from "../../../src/ccapi-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
