---
title: AWS IAM MCP Server
---

import ReadmeContent from "../../../src/iam-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
