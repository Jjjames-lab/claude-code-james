---
title: AWS Bedrock Custom Model Import MCP server
---

import ReadmeContent from "../../../src/aws-bedrock-custom-model-import-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
