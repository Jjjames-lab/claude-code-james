---
title: Amazon SNS SQS MCP Server
---

import ReadmeContent from "../../../src/amazon-sns-sqs-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
