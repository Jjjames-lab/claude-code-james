---
title: Amazon Bedrock Knowledge Base Retrieval MCP Server
---

import ReadmeContent from "../../../src/bedrock-kb-retrieval-mcp-server/README.md";

<div className="readme-content">
  <style>
    {`
    .readme-content h1:first-of-type {
      display: none;
    }
    `}
  </style>
  <ReadmeContent />
</div>
