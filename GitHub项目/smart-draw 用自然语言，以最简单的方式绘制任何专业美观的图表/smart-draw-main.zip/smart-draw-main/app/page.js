import DrawPage from '@/app/draw/page';

export default function Page() {
  return <DrawPage />;
}
