import type { Element } from '../../types';

export type Selection = Element[];
