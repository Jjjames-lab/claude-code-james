export interface IEditor {
  getDocument(): SVGSVGElement;
  destroy(): void;
}
