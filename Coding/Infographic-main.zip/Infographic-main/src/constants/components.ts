export const COMPONENT_ROLE = 'infographic-component';
