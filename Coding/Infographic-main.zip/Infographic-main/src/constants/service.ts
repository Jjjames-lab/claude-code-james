export const ICON_SERVICE_URL = 'https://www.weavefox.cn/api/open/v1/icon';
