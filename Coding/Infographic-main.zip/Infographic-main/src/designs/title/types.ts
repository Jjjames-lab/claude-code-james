export interface TitleOptions {
  type: string;
  [key: string]: any;
}
