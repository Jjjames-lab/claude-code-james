export const minifySvg = (str: string) => str.replace(/\n\s*/g, '').trim();
