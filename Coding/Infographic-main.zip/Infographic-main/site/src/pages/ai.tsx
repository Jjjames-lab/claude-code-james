import {AIPageContent} from 'components/AIPlayground';

export default function AIPlayground() {
  return <AIPageContent />;
}
