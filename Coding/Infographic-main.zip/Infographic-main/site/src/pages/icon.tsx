import {IconPageContent} from 'components/IconPage';

export default function IconPage() {
  return <IconPageContent />;
}
