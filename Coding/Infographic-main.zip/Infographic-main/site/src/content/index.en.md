---
id: home
title: AntV Infographic, an infographic generation and rendering framework that brings words to life.
permalink: index.html
---

{/* See HomeContent.tsx */}
