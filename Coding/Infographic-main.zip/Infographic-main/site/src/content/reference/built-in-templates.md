---
title: 内置模板
---

AntV Infographic 内置了多种信息图模板，可在[示例](/gallery)页面直接试用，快速生成成品。

使用 [getTemplates](/reference/infographic-exports#get-templates) 获取完整模板列表，或通过 [getTemplate](/reference/infographic-exports#get-template) 按 ID 获取配置。

若需自定义，可结合 [registerTemplate](/reference/infographic-exports#register-template) 注册自己的模板。
