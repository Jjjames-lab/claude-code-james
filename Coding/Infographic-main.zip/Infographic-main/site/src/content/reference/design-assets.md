---
title: 设计资产
---

AntV Infographic 提供了一系列内置设计资产，并会持续更新和扩展，帮助用户更高效地创建信息图表。

- [内置结构](/reference/built-in-structures)
- [内置数据项](/reference/built-in-items)
- [内置模板](/reference/built-in-templates)
- [内置色板](/reference/built-in-palettes)
- [内置图案](/reference/built-in-patterns)
- [内置组件](/reference/built-in-components)

所有资产都可与自定义能力搭配使用，快速覆盖常见场景。
