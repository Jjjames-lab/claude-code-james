---
title: 内置色板
---

AntV Infographic 内置了以下色板，并会在后续持续更新和扩展：

- AntV 品牌色(`antv`)
- `spectral`：一种渐变色板，适用于展示连续数据的场景

你可以通过 [getPalettes](/reference/infographic-exports#get-palettes) 方法获取完整的内置色板列表。

也可以通过 [getPalette](/reference/infographic-exports#get-palette) 方法，根据色板 ID 获取色板的具体色值或生成函数。
