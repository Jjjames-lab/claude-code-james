// Used in next.config.js to remove the raf transitive dependency.
export default window.requestAnimationFrame;
