// Used in next.config.js to remove the process transitive dependency.
module.exports = {
  env: {},
  cwd() {},
};
